[comment]: <> (Do not remove this!)
![Points badge](../../blob/badges/.github/badges/points.svg)
**Note that it may take 2-3 minutes for points to update after you push.**


# CS124 HTML Validator
## Getting familiar with standard library containers

## Why this Assignment Matters

Stacks, Queues and Lists are common but powerful data structures.  You'll use them frequently when coding projects.  Having a deep understanding of these data structures will help you create larger, more complicated projects.  You will not however, write a stack or queue from scratch every time you need one of these tools in your project.  Instead you'll turn to a data container provided by any number of libraries like the standard library for C++.  In this assignment you'll learn to use the STL containers so that you don't need to "reinvent the wheel" in the future. 


## Rubric

There are 100 total points possible in this assignment.

80 points will be autograded, with the remaining 20 points given by Prof. Raupach after checking  that your code for all parts followed the good coding practices listed in the rubric and discussed in class.

**Grading rubric 100 points (80 autograded)**

| Points | Requirements                                                                                                                                                                                                            |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 20     | Successfully validates a valid html file. (autograded)                                                                                                                                                                  |
| 20     | Fails to validate an invalid HTML fill with a missing opening tag (autograded)                                                                                                                                          |
| 20     | Fails to validate an invalid HTML fill with a missing closing tag (autograded)                                                                                                                                          |
| 20     | Fails to validate an invalid HTML when there are move opening tags than closing tags (autograded)                                                                                                                       |
| 20     | Good coding practices, including: self-commenting variable names, one statement per line, properly indenting and spacing, good  descriptive comments, and a lack of coding errors like memory leaks. (manually graded). |

***Note***: When you start this assignment you will have 60/80 points.  That is because the stub function returns false and three of the four tests are testing for false (invalid) results.  Once you attempt to get the valid HTML file running you'll likely start failing the invalid tests.  As always I reserve the right adjust the autograder scores in the positive or negative direction. 

***Note***: You are allowed unlimited attempts ahead of the due date.
So, if you do not achieve full  points after your initial submissions, you may resubmit as many times as you want until you have reached the deadline or achieved the point total you want.

## Developing and testing

In this assignment you only need to write one method, the HTMLChecker::isValid(). In this method you'll read from a std::queue and std::unordered_set and push and pop from a std::stack.  The objective of this assignment is you to get familiar with the standard library containers.  You can read about them here: https://www.cplusplus.com/reference/stl/ .  You must use these stack, queue and unsorted_set containers. Do not use other libraries.  

I've written the HTMLChecker::load() load method for you that reads in a html file and creates a queue of tags and words in the file.  There is also a self_closing_tags unsorted_set defined for you in the Class constructor.  

HTML uses nested tag to define the structure of a webpage.  This tag come in two forms, tags that open and close such as `<body>` and `</body>` and self closing tags such as `<br>` or `<br/>`. Our HTMLChecker is going to check to see that an HTML file as a closing tags for each opening tag and requires it and vice versa.  It will also make sure that the nested tags are in the correct nested order.

The checker will accomplish this by pushing tags on the stack when its finds an opening tag and popping tags off the stack when if it finds a matching closing tag.  If its finds a closing tag that does not match the opening tag on the stack then the HTML is invalid. The HTML is also invalid if the end of the queue is reached and the stack is not empty.

While putting tags on the stack you'll need to check them against a list of self-closing tags as you don't put them on the stack since they do not have corresponding closing tags.


## Specifics on how the checker algorithm should work
The load method that I wrote will create a queue named html_elements like this one with HTML tags and worked from the loaded HTML file.

![html as quueue](images/specifics01.png)
I've also given you a unordered_set of self-closing tags call self_closing_tags that you'll use to check if a html tag is self-closing.

![self closing tags](images/specifics02.png)

Your job is to right the isValid method that uses a Stack to validate the HTML is nested properly.
To do this you'll take opening HTML tags off the queue html_elements and put them on the stack. You'll need to discard words and self-closing html tags like `<br>` that are listed in the unordered_set self_closing_tags.

![process](images/specifics03.png)

When you reach a closing tag in html elements you'll pop the top item off the stack and see if it matches. If it does then keep going. 

![](images/specifics04.png)

If it doesn't then the HTML is invalid.

![](images/specifics05.png)

If on the other hand we made it to the end of html_elements and your stack was emty then the HTML is valid.

## Setting the"working Directory"

***Because we're working with files when you run the driver or tests you'll need to make sure you have the "working directory" set to the root directory of the project.***

I've set the working directory in the cMake file using the line `set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}")`. So there is a good chance you don't need to do anything to make this work properly. I've included a test in the CheckerTests called "The working path should be set" that should tell you if the working directory is set correctly or not.  

If you are having trouble loading in the example HTML files you may need to set the working directory yourself.

In cLion select "Edit Configurations" from the menu where you select the program to build and run.

![setting the working directory 1](images/WorkingDirectory01.png)

Then set the "Working directory:" field to the path where you've saved the project.  You'll need to do this for both the CheckerTest and the HTMLCheckerDriver.

![setting the working directory 2](images/WorkingDirectory02.png)


If you're using another IDE you'll have the lookup how to set it.  If you compile and run the application from the command line the working directory is just the directory you are currently in.

You use the main file as a driver to develop you code and test the results with the HTML_CheckerTest.  There are a few simple HTML files in samples for you to play with, feel free to add more.  Don't try and download modern webpages as HTML and test the code, there are just too many Javascript and CSS tags in most modern websites for our simple validator to handle. 
